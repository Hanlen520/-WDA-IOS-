#! /usr/bin/python
# -*- coding:utf-8 -*-  


import sys
import wda
import random
import math
import time
import xlrd
from xlwt import *
import json
import os


os.system("open -a Terminal.app runxcode.py")
time.sleep(20)
#连接真机时需要下面这条命令，用模拟器时可以注释该命令
#os.system("open -a Terminal.app connect.py")
defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

wda.DEBUG = False # default False
wda.HTTP_TIMEOUT = 60.0 # default 60.0 seconds
bundleid = sys.argv[1]
#与手机上的WebDriveAgent客户端链接
driver = wda.Client('http://localhost:8100')
# 启动应用，建立会话
#系统设置包名：com.apple.Preferences GO音乐包名：com.gomo.ios.music HD壁纸包名：com.hundred.ios.hdwallpaper
session = driver.session(bundleid)

# 取得屏幕大小
height = session.window_size().height
width = session.window_size().width
print('宽和高：%s %s' %(width,height))
#等待10s，用户进行初始化操作
time.sleep(5)


def swi_left(n):
    for i in range(n):
        session.swipe(350,350,50,350,0.5)
def swi_right(n):
    for i in range(n):
        session.swipe(50,350,350,350,0.5)
def swi_up(n):
    for i in range(n):
        session.swipe(200,600,200,200,0.5)
def swi_down(n):
    for i in range(n):
        session.swipe(200,200,200,600,0.5)
def alert_click(str):  #处理系统确认弹框,str传YES或NO
    print(session.alert.exists) #判断是否存在系统确认弹框
    if str == "YES":
        session.alert.accept()  #点击确认按钮
    else:
        session.alert.dismiss() #点击取消按钮
#    session.alert.buttons() #返回弹框按钮的文案
#    session.alert.click(str)    #点击弹框上的按钮，str传按钮文案
def click(str):
    session(text=str).click()
def click_exists(str):
    session(text=str).click_exists()
def tap(x,y):
    session.tap(x,y)
def tap_hold(x,y,t):    # tap hold
    session.tap_hold(x,y,t)
def tap_hold_elements(str,t):   # tap And Hold for 1.0s
    session(text=str).tap_hold(t)
def find_elements(str,n):   # find the second element. index starts from 1
    session(name=str,index=n).click()
def match_part(str):  # predicate is the first argument, without predicate= is ok
#session('name LIKE "Latest*s"').click()
    session(predicate='name LIKE "Latest*"').click()
def pinch(str):
    session(text=str).pinch(2,1)
def scroll(str):
    session(text=str).scroll("up")
def home():
    driver.home()
def startapp(bundleid):
    session=driver.session(bundleid)
    return session
def matchClick(str):
    session(labelContains=str).click_exists()
def scroll_click(str):
    #session(label=str).scroll()
    while session(label=str).displayed == False:
        swi_up(1)
    #print(session(label=str).displayed)
    session(label=str).click_exists()
def getelements(str):
    list = session(text=str).find_elements()
    return list
def textIN(str1,str2):
    try:
        e = session(text=str1).get()
        e.set_text(str2)
        #set_text("Hello WDA") # normal usage
        #set_text("Hello WDA\n") # send text with enter
        #set_text("\b\b\b") # delete 3 chars
    except Exception:
        e = session(className=str1).get()
        e.set_text(str2)
#check某字符串是否存在该界面中，返回布尔值
def getType(strs):
    for each in strs:
        if session(labelContains=each).exists == False and session(value=each).exists == False:
            return False
            break
#某个界面含多个相同元素名，且需要上下滑动才能显示完的全部，我们只需要点击其中一个元素时调用tapMoreElement(str,n1,n2)方法，str为元素名、n1为需要点击的那个元素的下标，n2为需要向下滑动的次数
def tapMoreElement(str,n1,n2):
    swi_up(n2)
    print(str)
    session(text=str)[n1].click()


notmatch = []
def matchStr(list,a,b):
    for i in range(a-2,b-1):
        try:
            global session
            time.sleep(0.5)
            if list[i] == "":
                continue
            elif session(text=list[i]).exists == False and session(value=list[i]).exists == False:
                print("not found \033[1;35m %s \033[0m,add to notmatch! " %list[i])
                notmatch.append(list[i])
                continue
            else:
                print("\033[1;35m %s \033[0m is ok! " %list[i])
        except Exception,e:
            print("\033[5;31m 发生错误：\033[0m"+str(e))
            session = driver.session(bundleid)
def matchStrN(list,string,a,b):
    for i in range(a-2,b-1):
        try:
            global session
            time.sleep(0.5)
            #把list[0]字符串重新进行切片分割为一个个单词，然后去掉其中的str字段，再将这些单词去匹配是否存在
            strs = list[i].split(" ")
            print("strs:"+json.dumps(strs,ensure_ascii=False,encoding="utf-8"))
            if string in strs:
                strs.remove(string)
                print("strs:"+json.dumps(strs,ensure_ascii=False,encoding="utf-8"))
            if getType(strs) == False:
                print("not found \033[1;35m %s \033[0m,add to notmatch! " %list[i])
                notmatch.append(list[i])
            else:
                print("\033[1;35m %s \033[0m is ok! " %list[i])
        except Exception,e:
            print("\033[5;31m 发生错误：\033[0m"+str(e))
            session = driver.session(bundleid)

fileName="./test.xlsx"
workbook=xlrd.open_workbook(fileName)   #打开excel
#shxrange=(workbook.nsheets)   #获取工作表数
sheet=workbook.sheet_by_name("Sheet1")  #获取工作表
#nname=sheet.name   #获取sheet名称
#nrows=sheet.nrows   #获取行数
ncols=sheet.ncols   #获取列数
#获取单元格内容的三种方法
#sheet.cell(1,0).value.encode('utf-8')
#sheet.cell_value(1,0).encode('utf-8')
#sheet.row(1)[0].value.encode('utf-8')
# 获取单元格内容的数据类型
#sheet.cell(1,3).ctype
#print(ncols)
#rows=sheet.row_values(3)    #获取某行的所有值，以列表形式存储
#cols=sheet.col_values(0)   #获取某列的所有值，以列表形式存储
def getdata(row,col):   ##获取单元格数据
    data = sheet.cell(row,col).value.encode('utf-8')
    return data
def getListCols(i): ##获取某列的所有值，以列表形式存储
    cols = sheet.col_values(i)
    return cols
def getListRows(i): ##获取某行的所有值，删除第一个表格数据，然后以列表形式存储
    rows = sheet.row_values(i-1)
    del rows[0]
    return rows

##由于ios系统组件未设置属性名称等，无法通过属性值去定位，故通过text来定位元素
list1 = ["简体中文","完成","更改"]
list2 = ["繁體中文","完成","改成"]
list3 = ["English","Done","Change"]
list4 = ["한국어","완료","변경"]
list5 = ["Français","OK","Passer"]
list6 = ["Deutsch","Fertig","verwenden"]
list7 = ["Português (Portugal)","OK","Alterar"]
list8 = ["Español","Listo","Cambiar"]
list9 = ["Русский","Готово","Сменить"]
list10 = ["Bahasa Indonesia","Selesai","Ubah"]
list11 = ["हिन्दी","पूर्ण","परिवर्तित"]
list12 = ["العربية","تم"," تغيير"]
list13 = ["日本語","完了","変更"]
list14 = ["ภาษาไทย","เสร็จสิ้น","เปลี่ยนเป็"]
list15 = ["Tiếng Việt","Xong","Đổi"]
list16 = ["Italiano","Fine","Modifica"]
list17 = ["Bahasa Melayu","Selesai","Tukar"]
list18 = ["Türkçe","Bitti","Değiştir"]
list19 = ["română","OK","în limba "]
temp = {"zh-CN":list1,"zh-TW":list2,"en":list3,"ko":list4,"fr":list5,"de":list6,"pt":list7,"es":list8,"ru":list9,"id":list10,"hi":list11,"ar":list12,"jp":list13,"th":list14,"vn":list15,"it":list16,"ms":list17,"tr":list18,"ro":list19}

def switchLanguage(currlanguage,nextlanguage):
    list = temp.get(currlanguage)
    matchClick("iPhone")
    scroll_click(temp.get(nextlanguage)[0])
    click(list[1])
    matchClick(list[2])



