#! /usr/bin/python
# -*- coding:utf-8 -*-  
import sys
import os
import module
import time
import json

#list1=["धन्यवाद","12 Bulan: $79,99/tahun","ありがとうございました","Đang tải xuống……","ขอบคุณ"]
#Str=["更多","更多","More","المزيد","詳細","더 보기","Plus","Mehr","Altro","Mais","Больше","Más","มากขึ้น","Thêm","अधिक","Lebih","Banyak Lagi"]

#module.swi_left(n)    左滑n次
#module.swi_right(n)    右滑n次
#module.swi_up(n)      上滑n次
#module.swi_down(n)    下滑n次
#module.click(str)    点击元素，str传元素的名称(当找不到该元素时程序会报错)
#module.click_exists(str)      元素存在则点击，不存在则忽略，str传元素名称(当找不到该元素时程序不会报错)
#module.tap(x,y)       点击坐标,x横坐标、y纵坐标
#module.pinch(str)    对元素进行捏操作，str传元素的名称
#module.scroll(str)    对元素进行向上滚动操作，str传元素的名称
#module.scroll_click(str)      滚动使元素可见并点击，str传元素的名称，(元素在可见状态下才可点击，如果某页面需要滚动才能看到该元素就可调用该方法)
#module.home()         按hone键
#module.matchStr(list,a,b)     完全匹配多语言，格式：matchStr(列表，开始行数，结束行数),列表统一都传list,a为需要匹配的多语言表格的开始行数，b为需要匹配的多语言表格的结束行数，只匹配一行也需要填写a和b，a=b即可
#module.matchStrN(list,str,a,b)    不完全匹配多语言，针对如："在YouTube上搜索 XXX"这种类型的多语言，因为该方法采用的是字符串切片法，“XXX”和前面的语言之间必须要有空格。格式：matchStrN(列表，要剔除的字符，开始行数，结束行数),列表统一都传list，str为需要剔除的字符如“XXX”，a为需要匹配的多语言表格的开始行数，b为需要匹配的多语言表格的结束行数，只匹配一行也需要填写a和b，a=b即可
#module.getListCols(i)     获取表格第i列的所有多语言
#module.getListRows(i)     获取表格第i行的所有多语言
#module.switchLanguage(currlanguage,nextlanguage)   切换手机系统当前语言到下一个语言
#module.startapp(bundleid)     启动app
#module.matchClick(str)    通过Label属性的不完整关键词模糊匹配含字符串str的元素，匹配成功则点击，否则忽略
#module.getdata(row,col)   获取某一单元格的数据，row行数 col列数
#module.getelements(str)   找到当前界面所有与str字符串相匹配的字符，返回一个列表
#module.textIN(str1,str2)  定位输入框并输入，str1为需要定位的输入框的元素名，str2为需要输入的字符
#module.alert_click(str)   处理程序内出现的系统确认弹框,str传YES或NO选择点击确认或取消


bundleid = sys.argv[1]
currlanguage = ""
nextlanguage = ""
for i in range(1,module.ncols):    # module.ncols
    #print("总共需要匹配%s种语言！" %(module.ncols-1))
    list=module.getListCols(i)
    print("当前执行匹配语言："+list[0])
    currlanguage = list[0]
    module.notmatch.append(currlanguage)
    del list[0]
    
    ############################下面区域写用例###########################
    
    
    #此处写用例（以下仅供参考），如果只有一个场景需要测试，则只写一个用例即可
    #第一个用例：用户登录模块
#    print("用例一：用户登录模块邮箱注册...")
#    module.tap(363,712)    #点击个人页TAB
#    module.tap(363,270)    #点击账号入口
#    module.matchStr(list,79,81)
#    module.tap(207,638)
#    module.matchStr(list,49,54)
    #第二个用例：图片裁剪模块
    print("用例二：图片裁剪模块...")
    module.tap(25,25)    #点击可能在启动页后出现的订阅引导页的关闭按钮
    module.tap(363,712)
    module.tap(367,641) #点击选择照片入口
    module.matchStr(list,2,3)
    module.tap(344,132) #点击选择一张图片
    module.tap(364,42)  #选择照片后点下一步
    module.matchStr(list,24,24)
    module.matchStr(list,21,21)
    module.matchStr(list,14,14)
    module.matchStrN(list,"100MB",15,15)
    module.matchStr(list,16,16)
    module.click_exists("btn edit normal")  #点击裁剪按钮
    module.matchStr(list,9,12)
    module.click_exists("btn crop close normal")   #裁剪完成点击取消,"btn crop save selected"是确定
    module.textIN("TextField","hello")  #输入图片名称
    module.tap(367,25)  #点击发布按钮
    module.click_exists("button back normal")
    module.tap(30,30)
    module.click_exists("button back normal")
    module.matchStr(list,18,20)
    module.tap(207,660) #点击放弃草稿
#    #第三个用例：上传壁纸模块
#    print("用例三：我的上传模块，三个tab已有数据的场景...")
#    module.tap(367,641) #点击选择照片入口
#    module.tap(360,42)  #点击发布按钮
#    time.sleep(1)
#    module.matchStr(list,17,17)
#    module.matchStrN(list,"100.5MB",27,27)
#    module.matchStr(list,29,29)
#    module.tap(284,482)  #上传按钮点击
#
#    module.matchStr(list,32,35)
#    module.tap(105,263)    #点击暂停上传
#    module.matchStr(list,45,45)
#    module.tap(105,263)    #点击开始上传
#    module.matchStr(list,46,47)
#    module.swi_right(1)
#    module.matchStr(list,39,40)
#    module.swi_right(1)
#    module.matchStr(list,42,43)
#    module.swi_down(1)
#    module.matchStr(list,37,37)

#    print("用例三：我的上传模块，三个tab无数据的场景...")
#    module.tap(367,320) #点击我的入口
#    module.click_exists("icon_projects")
#    module.matchStr(list,36,36)
#    module.swi_left(1)
#    module.matchStr(list,38,38)
#    module.swi_left(1)
#    module.matchStr(list,44,44)
#
#    module.click_exists("button back normal")
#    module.click_exists("button back normal")

    
    #第四个用例：设置界面
    print("用例四：设置界面...")
    
    #第五个用例：三选项单按钮订阅页
    print("用例五：三选项单按钮订阅页...")
    
    
    
    
    
    ############################上面区域写用例###########################
    
    #将未找到的多语言写到文件内
    print("\033[1;31m未找到的多语言有：\033[0m"+json.dumps(module.notmatch,ensure_ascii=False,encoding="utf-8"))
    file=open("notmatch.txt","w")
    for each in module.notmatch:
        file.write(each)
        file.write("\n")
    file.close()

    if i == module.ncols-1:     #module.ncols-1
        print("TEST COMPLETE !")
        sys.exit()
    nextlanguage = module.getdata(0,i+1)
    print("切换地区语言为%s..." %nextlanguage)
    module.session = module.driver.session("com.apple.Preferences")
    module.switchLanguage(currlanguage,nextlanguage)
    time.sleep(15)
    os.system("open -a Terminal.app runxcode.py")
    time.sleep(18)
    module.session = module.driver.session(bundleid)


