#! /usr/bin/python
# -*- coding:utf-8 -*-  
import os

os.system("iproxy 8100 8100")



